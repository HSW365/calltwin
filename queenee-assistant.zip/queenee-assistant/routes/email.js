const express = require('express');
const multer = require('multer');
const { handleIncomingEmail } = require('../services/emailEngine');
const { sendReply, alertOwner } = require('../services/emailSend');
const { EmailLog } = require('../services/db');

const router = express.Router();
const upload = multer();

// SendGrid's Inbound Parse webhook posts multipart/form-data with fields
// like from, to, subject, text, html, envelope. multer() with no fields
// config just parses the multipart body for us.
router.post('/incoming', upload.none(), async (req, res) => {
  // Always 200 back to SendGrid immediately so it doesn't retry/backlog —
  // we do the real work after responding.
  res.sendStatus(200);

  const fromAddress = req.body.from || 'unknown';
  const subject = req.body.subject || '(no subject)';
  const bodyText = req.body.text || req.body.html || '';

  if (!bodyText.trim()) {
    console.warn('[email] Received empty body from', fromAddress, '— skipping.');
    return;
  }

  try {
    const { category, shouldAutoReply, replyText, ownerSummary } = await handleIncomingEmail({
      fromAddress,
      subject,
      bodyText
    });

    const escalated = !shouldAutoReply;

    if (process.env.MONGODB_URI) {
      EmailLog.create({
        fromAddress,
        toAddress: req.body.to || '',
        subject,
        incomingText: bodyText,
        aiReplyText: replyText,
        category,
        autoReplied: shouldAutoReply,
        escalatedToOwner: escalated
      }).catch((e) => console.error('[email] log create failed:', e.message));
    }

    if (shouldAutoReply && replyText) {
      await sendReply({ toAddress: fromAddress, subject, replyText });
    }

    await alertOwner({ fromAddress, summary: ownerSummary, category, escalated });
  } catch (err) {
    console.error('[email] processing failed:', err.message);
  }
});

module.exports = router;
