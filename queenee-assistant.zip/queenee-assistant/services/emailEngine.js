const Anthropic = require('@anthropic-ai/sdk');

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SYSTEM_PROMPT = `You are the 24/7 AI virtual front desk for ${process.env.BUSINESS_NAME || 'this business'}.
Business description: ${process.env.BUSINESS_DESCRIPTION || 'a local service business'}.

You are replying to an inbound email. Read it and respond with a JSON object ONLY, no other text,
no markdown fences, matching exactly this shape:

{
  "category": "lead" | "support" | "billing_complaint" | "spam_or_unclear" | "other",
  "should_auto_reply": true | false,
  "reply_text": "the email body to send back, written as warm professional plain-text email copy, max 120 words, ending with a real sign-off",
  "owner_summary": "one sentence summary of what this email is about, for an internal alert"
}

Rules for category + should_auto_reply:
- "lead" (someone interested in services / wants a quote / wants to book something): should_auto_reply = true. Confirm receipt, say someone will follow up within 1 business day, ask any one clarifying question if needed.
- "support" (existing customer with a simple question you can plainly answer from the business description): should_auto_reply = true.
- "billing_complaint" (anything about money, refunds, being upset, a dispute, legal threats, or anything sensitive): should_auto_reply = false. reply_text should still be a polite holding reply ("we received this and a team member will personally respond shortly") but it will NOT be sent automatically — a human reviews it first.
- "spam_or_unclear" (junk, unrelated, or you genuinely can't tell what they want): should_auto_reply = false.
- "other": anything that doesn't fit above. Default should_auto_reply to false when unsure.

Never invent specific prices, dates, or promises you don't actually know. Keep it human, never robotic-sounding, no emoji.`;

async function handleIncomingEmail({ fromAddress, subject, bodyText }) {
  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 400,
    system: SYSTEM_PROMPT,
    messages: [
      {
        role: 'user',
        content: `From: ${fromAddress}\nSubject: ${subject}\n\n${bodyText}`
      }
    ]
  });

  const raw = response.content
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join('')
    .trim();

  try {
    const cleaned = raw.replace(/^```json\s*|\s*```$/g, '');
    const parsed = JSON.parse(cleaned);
    return {
      category: parsed.category || 'other',
      shouldAutoReply: !!parsed.should_auto_reply,
      replyText: parsed.reply_text || '',
      ownerSummary: parsed.owner_summary || 'New email received.'
    };
  } catch (err) {
    console.error('[emailEngine] Failed to parse model output, defaulting to manual review:', err.message);
    return {
      category: 'other',
      shouldAutoReply: false,
      replyText: '',
      ownerSummary: `Could not auto-classify email from ${fromAddress} — needs manual review.`
    };
  }
}

module.exports = { handleIncomingEmail };
