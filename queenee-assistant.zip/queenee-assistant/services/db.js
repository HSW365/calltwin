const mongoose = require('mongoose');

async function connectDB() {
  if (!process.env.MONGODB_URI) {
    console.warn('[db] MONGODB_URI not set — running without persistence (logs only).');
    return;
  }
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('[db] Connected to MongoDB');
  } catch (err) {
    console.error('[db] Connection failed:', err.message);
  }
}

const callLogSchema = new mongoose.Schema({
  callSid: { type: String, index: true },
  fromNumber: String,
  toNumber: String,
  transcript: [
    {
      role: { type: String, enum: ['caller', 'assistant'] },
      text: String,
      at: { type: Date, default: Date.now }
    }
  ],
  status: { type: String, enum: ['in_progress', 'completed', 'lead_qualified'], default: 'in_progress' },
  callerName: String,
  callbackNumber: String,
  reasonForCall: String,
  preferredCallbackTime: String,
  startedAt: { type: Date, default: Date.now },
  endedAt: Date
});

const emailLogSchema = new mongoose.Schema({
  fromAddress: String,
  toAddress: String,
  subject: String,
  incomingText: String,
  aiReplyText: String,
  category: {
    type: String,
    enum: ['lead', 'support', 'billing_complaint', 'spam_or_unclear', 'other'],
    default: 'other'
  },
  autoReplied: { type: Boolean, default: false },
  escalatedToOwner: { type: Boolean, default: false },
  receivedAt: { type: Date, default: Date.now }
});

const CallLog = mongoose.model('CallLog', callLogSchema);
const EmailLog = mongoose.model('EmailLog', emailLogSchema);

module.exports = { connectDB, CallLog, EmailLog };
