const express = require('express');
const twilio = require('twilio');
const { handleTurn } = require('../services/conversationEngine');
const { notifyOwnerOfLead } = require('../services/notify');
const { CallLog } = require('../services/db');

const router = express.Router();
const VoiceResponse = twilio.twiml.VoiceResponse;

const GREETING =
  process.env.GREETING ||
  `Thanks for calling, this is your virtual assistant, how can I help you today?`;

// Twilio hits this the moment a call comes in.
router.post('/incoming', async (req, res) => {
  const { CallSid, From, To } = req.body;

  if (process.env.MONGODB_URI) {
    CallLog.create({ callSid: CallSid, fromNumber: From, toNumber: To }).catch((e) =>
      console.error('[voice] log create failed:', e.message)
    );
  }

  const twiml = new VoiceResponse();
  const gather = twiml.gather({
    input: 'speech',
    action: '/voice/respond',
    method: 'POST',
    speechTimeout: 'auto',
    speechModel: 'phone_call'
  });
  gather.say({ voice: 'Polly.Joanna' }, GREETING);

  // If the caller says nothing at all, don't just hang up silently.
  twiml.say({ voice: 'Polly.Joanna' }, "I didn't catch that. Please call back and try again. Goodbye!");
  twiml.hangup();

  res.type('text/xml').send(twiml.toString());
});

// Every subsequent turn of the conversation comes back through here.
router.post('/respond', async (req, res) => {
  const { CallSid, From, SpeechResult } = req.body;
  const twiml = new VoiceResponse();

  try {
    const { reply, done, qualified, summary } = await handleTurn(CallSid, SpeechResult, From);

    twiml.say({ voice: 'Polly.Joanna' }, reply);

    if (qualified) {
      if (process.env.MONGODB_URI) {
        CallLog.findOneAndUpdate(
          { callSid: CallSid },
          { status: 'lead_qualified', reasonForCall: summary, endedAt: new Date() }
        ).catch((e) => console.error('[voice] log update failed:', e.message));
      }
      await notifyOwnerOfLead({ fromNumber: From, summary });
      twiml.hangup();
    } else if (done) {
      if (process.env.MONGODB_URI) {
        CallLog.findOneAndUpdate({ callSid: CallSid }, { status: 'completed', endedAt: new Date() }).catch(() => {});
      }
      twiml.hangup();
    } else {
      const gather = twiml.gather({
        input: 'speech',
        action: '/voice/respond',
        method: 'POST',
        speechTimeout: 'auto',
        speechModel: 'phone_call'
      });
      // Twilio re-prompts with empty gather; caller just speaks after hearing the reply above.
      void gather;
    }
  } catch (err) {
    console.error('[voice] turn failed:', err.message);
    twiml.say(
      { voice: 'Polly.Joanna' },
      "Sorry, I'm having trouble right now. Please try calling back in a few minutes."
    );
    twiml.hangup();
  }

  res.type('text/xml').send(twiml.toString());
});

module.exports = router;
