const Anthropic = require('@anthropic-ai/sdk');

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// In-memory per-call conversation state. Fine for a single Render instance;
// if you scale to multiple instances later, move this to Mongo/Redis.
const sessions = new Map();

function getSession(callSid) {
  if (!sessions.has(callSid)) {
    sessions.set(callSid, { messages: [], turns: 0, qualified: false, extracted: {} });
  }
  return sessions.get(callSid);
}

function endSession(callSid) {
  sessions.delete(callSid);
}

const SYSTEM_PROMPT = `You are the 24/7 AI virtual front desk receptionist for ${process.env.BUSINESS_NAME || 'this business'}.
Business description: ${process.env.BUSINESS_DESCRIPTION || 'a local service business'}.

Your job on every call:
1. Greet warmly, find out who is calling and why (sales lead, existing customer, support, etc).
2. Get their name and the best callback number if different from the number they're calling from.
3. Get a short description of what they need.
4. Ask what day/time works best for a callback.
5. Once you have name + reason + callback time, thank them, confirm someone will reach out, and end the call politely.

Rules:
- Keep every response SHORT — 1 to 2 sentences. This is a live phone call, not a chat.
- Speak naturally, like a friendly real receptionist. No emoji, no markdown, no lists — plain spoken sentences only.
- Never make up business details you don't know. If asked something you can't answer, say a team member will follow up with details.
- Once you have captured name, reason, and a callback time/window, output a final line starting with exactly "LEAD_QUALIFIED:" followed by a one-sentence summary, then say goodbye in the same turn.
- If the caller is rude, confused, or it's clearly a wrong number, politely end the call without forcing the qualification flow.`;

/**
 * Run one conversational turn.
 * @param {string} callSid
 * @param {string} callerSpeech - transcribed text from Twilio <Gather>
 * @param {string} fromNumber
 * @returns {Promise<{reply: string, done: boolean, qualified: boolean, summary: string|null}>}
 */
async function handleTurn(callSid, callerSpeech, fromNumber) {
  const session = getSession(callSid);
  session.turns += 1;

  session.messages.push({ role: 'user', content: callerSpeech || '(no speech detected)' });

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 200,
    system: SYSTEM_PROMPT,
    messages: session.messages
  });

  const rawText = response.content
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join(' ')
    .trim();

  session.messages.push({ role: 'assistant', content: rawText });

  let qualified = false;
  let summary = null;
  let reply = rawText;

  const marker = 'LEAD_QUALIFIED:';
  const idx = rawText.indexOf(marker);
  if (idx !== -1) {
    qualified = true;
    summary = rawText.slice(idx + marker.length).trim();
    // Strip the machine-readable marker out of what gets spoken to the caller
    reply = rawText.slice(0, idx).trim() || "Thanks so much — someone will reach out to you shortly. Have a great day!";
  }

  // Safety valve: hang up after too many turns even if not qualified, so calls
  // can never loop forever and rack up Twilio minutes.
  const forceDone = session.turns >= 8;

  if (qualified || forceDone) endSession(callSid);

  return {
    reply,
    done: qualified || forceDone,
    qualified,
    summary
  };
}

module.exports = { handleTurn };
