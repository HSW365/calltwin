const twilio = require('twilio');

let client = null;
if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
  client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
}

async function notifyOwnerOfLead({ fromNumber, summary }) {
  if (!client || !process.env.OWNER_PHONE_NUMBER || !process.env.TWILIO_PHONE_NUMBER) {
    console.warn('[notify] Twilio SMS not configured — skipping owner alert. Lead:', summary);
    return;
  }
  try {
    await client.messages.create({
      body: `🔔 New lead from your virtual front desk!\nFrom: ${fromNumber}\n${summary}`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: process.env.OWNER_PHONE_NUMBER
    });
    console.log('[notify] Owner alerted via SMS');
  } catch (err) {
    console.error('[notify] Failed to send owner SMS:', err.message);
  }
}

module.exports = { notifyOwnerOfLead };
