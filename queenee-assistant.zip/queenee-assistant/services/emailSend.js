const sgMail = require('@sendgrid/mail');

if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

async function sendReply({ toAddress, subject, replyText }) {
  if (!process.env.SENDGRID_API_KEY || !process.env.SENDGRID_FROM_ADDRESS) {
    console.warn('[emailSend] SendGrid not configured — skipping send. Would have sent:', replyText);
    return;
  }
  try {
    await sgMail.send({
      to: toAddress,
      from: process.env.SENDGRID_FROM_ADDRESS,
      subject: subject?.toLowerCase().startsWith('re:') ? subject : `Re: ${subject || 'Your message'}`,
      text: replyText
    });
    console.log('[emailSend] Auto-reply sent to', toAddress);
  } catch (err) {
    console.error('[emailSend] Send failed:', err.message);
  }
}

async function alertOwner({ fromAddress, summary, category, escalated }) {
  if (!process.env.SENDGRID_API_KEY || !process.env.SENDGRID_FROM_ADDRESS || !process.env.OWNER_EMAIL_ADDRESS) {
    console.warn('[emailSend] Owner email alert not configured — skipping. Summary:', summary);
    return;
  }
  try {
    await sgMail.send({
      to: process.env.OWNER_EMAIL_ADDRESS,
      from: process.env.SENDGRID_FROM_ADDRESS,
      subject: escalated
        ? `⚠️ NEEDS YOUR REVIEW — ${category} email from ${fromAddress}`
        : `New ${category} email handled automatically — ${fromAddress}`,
      text: summary
    });
  } catch (err) {
    console.error('[emailSend] Owner alert failed:', err.message);
  }
}

module.exports = { sendReply, alertOwner };
